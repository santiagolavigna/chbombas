<?php
  $page_title = 'Panel de control';
  // Checkin What level user has permission to view this page
   page_require_level(1);
?>
<?php
 $c_categorie     = count_by_id('categorias');
 $c_product       = count_by_id('productos');

 
 $recent_products = find_recent_product_added('5');

?>

  <div class="row">
 
    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon pull-left bg-red">
          <i class="glyphicon glyphicon-list"></i>
        </div>
        <div class="panel-value pull-right">
          <h2 class="margin-top"> <?= $c_categorie['total'] ?> </h2>
          <p class="text-muted">Categorías</p>
        </div>
       </div>
    </div>
    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon pull-left bg-blue">
          <i class="glyphicon glyphicon-shopping-cart"></i>
        </div>
        <div class="panel-value pull-right">
          <h2 class="margin-top"> <?= $c_product['total'] ?> </h2>
          <p class="text-muted">Productos</p>
        </div>
       </div>
    </div> 
  
</div>

  <div class="row">
  

  <div class="col-md-4">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Productos recientemente añadidos</span>
        </strong>
      </div>
      <div class="panel-body">

        <div class="list-group">

      <?php foreach ($recent_products as  $recent_product): ?>
            <a class="list-group-item clearfix">
                <h4 class="list-group-item-heading">
                    <img class="img-avatar img-circle" src="uploads/products/no_image.jpg" alt="">
                  <img class="img-avatar img-circle" src="uploads/products/<?php echo $recent_product['image'];?>" alt="" />
                <?= remove_junk(first_character($recent_product['nombre']));?>
                  <span class="label label-warning pull-right">
                 $<?= $recent_product['precio_venta']; ?>
                  </span>
                </h4>
                <span class="list-group-item-text pull-right">
                <?= remove_junk(first_character($recent_product['categorie'])); ?>
              </span>
           </a>
      <?php endforeach; ?>
    </div>
  </div>
 </div>
</div>
 </div>
  <div class="row">
  </div>
