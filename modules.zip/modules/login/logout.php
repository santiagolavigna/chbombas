<?php
  if(!$session->logout()) {redirect('?p=login|login',false);}
?>
